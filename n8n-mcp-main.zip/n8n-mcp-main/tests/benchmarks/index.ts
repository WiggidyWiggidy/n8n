// Export all benchmark suites
// Note: Some benchmarks are temporarily disabled due to API changes
// export * from './node-loading.bench';
export * from './database-queries.bench';
// export * from './search-operations.bench';
// export * from './validation-performance.bench';
// export * from './mcp-tools.bench';